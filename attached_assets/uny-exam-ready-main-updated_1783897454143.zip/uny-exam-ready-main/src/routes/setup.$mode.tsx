import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Clock, Layers, ListChecks, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { QUESTIONS, SUBSKILLS } from "@/data/questions";
import { createActiveExam, difficultyDistribution, pickFromSection } from "@/lib/engine";
import { getWrongIds, saveActiveExam } from "@/lib/storage";
import { SECTION_IDS, SECTION_LABELS } from "@/lib/analysis";
import { fmtMinutes } from "@/lib/format";
import type { ExamMode, Question, SectionId } from "@/lib/types";

export const Route = createFileRoute("/setup/$mode")({
  head: () => ({
    meta: [
      { title: "Persiapan Simulasi — UNY CBT Trainer" },
      { name: "description", content: "Atur simulasi latihan CBT sebelum mulai mengerjakan." },
    ],
  }),
  component: SetupPage,
});

const MODE_INFO: Record<string, { title: string; desc: string }> = {
  mini: { title: "Mini TO", desc: "Simulasi singkat semua bagian untuk pemanasan rutin." },
  full: { title: "Full TO", desc: "Simulasi panjang semua bagian untuk melatih daya tahan." },
  materi: { title: "Latihan Per Materi", desc: "Fokus pada satu bagian atau subskill tertentu." },
  review: { title: "Review Kesalahan", desc: "Kerjakan ulang soal yang pernah kamu jawab salah." },
};

function SetupPage() {
  const { mode } = Route.useParams();
  const navigate = useNavigate();
  const info = MODE_INFO[mode];

  const [section, setSection] = useState<SectionId>("tpa");
  const [subskill, setSubskill] = useState<string>("");
  const [selection, setSelection] = useState<Question[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!info) {
      navigate({ to: "/" });
      return;
    }
    let picked: Question[] = [];
    if (mode === "mini") {
      picked = SECTION_IDS.flatMap((s) => pickFromSection(s, 3));
    } else if (mode === "full") {
      picked = SECTION_IDS.flatMap((s) => pickFromSection(s, 10));
    } else if (mode === "materi") {
      picked = pickFromSection(section, 10, subskill || undefined);
    } else if (mode === "review") {
      const wrong = new Set(getWrongIds());
      picked = QUESTIONS.filter((q) => wrong.has(q.id)).slice(0, 15);
    }
    setSelection(picked);
    setReady(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, section, subskill]);

  const durationSec = useMemo(() => {
    if (mode === "mini") return 15 * 60;
    if (mode === "full") return 50 * 60;
    const est = selection.reduce((a, q) => a + q.estimatedTime, 0);
    return Math.max(5 * 60, Math.ceil((est * 1.2) / 60) * 60);
  }, [mode, selection]);

  if (!info) return null;

  const dist = difficultyDistribution(selection);
  const includedSections = [...new Set(selection.map((q) => q.section))];

  const start = () => {
    if (selection.length === 0) return;
    const exam = createActiveExam({
      mode: mode as ExamMode,
      title:
        mode === "materi"
          ? `Latihan ${subskill || SECTION_LABELS[section]}`
          : info.title,
      questionIds: selection.map((q) => q.id),
      durationSec,
      shuffleOptions: true,
    });
    saveActiveExam(exam);
    navigate({ to: "/exam" });
  };

  return (
    <div className="mx-auto min-h-screen w-full max-w-2xl px-4 py-4">
      <div className="mb-4 flex items-center gap-3">
        <Link
          to="/"
          className="grid h-9 w-9 place-items-center rounded-lg border bg-card text-foreground"
          aria-label="Kembali"
        >
          <ArrowLeft className="h-4.5 w-4.5" />
        </Link>
        <div className="min-w-0">
          <h1 className="truncate text-lg font-extrabold">{info.title}</h1>
          <p className="truncate text-xs text-muted-foreground">{info.desc}</p>
        </div>
      </div>

      {mode === "materi" && (
        <Card className="mb-4">
          <CardContent className="p-4">
            <p className="mb-2 text-sm font-bold">Pilih bagian</p>
            <div className="mb-3 grid grid-cols-1 gap-2">
              {SECTION_IDS.map((s) => (
                <button
                  key={s}
                  onClick={() => {
                    setSection(s);
                    setSubskill("");
                  }}
                  className={`rounded-xl border px-3.5 py-2.5 text-left text-sm font-medium transition-colors ${
                    section === s
                      ? "border-primary bg-primary/10 text-primary"
                      : "bg-card text-foreground"
                  }`}
                >
                  {SECTION_LABELS[s]}
                </button>
              ))}
            </div>
            <p className="mb-2 text-sm font-bold">Subskill (opsional)</p>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSubskill("")}
                className={`rounded-full border px-3 py-1.5 text-xs font-medium ${
                  subskill === "" ? "border-primary bg-primary/10 text-primary" : "bg-card"
                }`}
              >
                Semua
              </button>
              {(SUBSKILLS[section] ?? []).map((ss) => (
                <button
                  key={ss}
                  onClick={() => setSubskill(ss)}
                  className={`rounded-full border px-3 py-1.5 text-xs font-medium ${
                    subskill === ss ? "border-primary bg-primary/10 text-primary" : "bg-card"
                  }`}
                >
                  {ss}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {ready && mode === "review" && selection.length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center">
            <p className="font-bold">Belum ada soal untuk direview</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Kerjakan simulasi dulu — soal yang salah akan otomatis masuk ke sini.
            </p>
            <Button asChild className="mt-4">
              <Link to="/setup/$mode" params={{ mode: "mini" }}>
                Mulai Mini TO
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card className="mb-4">
            <CardContent className="grid gap-3 p-4">
              <Row icon={ListChecks} label="Jumlah soal" value={`${selection.length} soal`} />
              <Row icon={Clock} label="Batas waktu" value={fmtMinutes(durationSec)} />
              <Row
                icon={Layers}
                label="Bagian"
                value={
                  includedSections.length === 4
                    ? "Semua bagian (4)"
                    : includedSections.map((s) => SECTION_LABELS[s]).join(", ") || "—"
                }
              />
              <div>
                <p className="mb-1.5 text-xs font-semibold text-muted-foreground">
                  Distribusi kesulitan
                </p>
                <div className="flex gap-2">
                  <Badge variant="secondary">Mudah: {dist.mudah}</Badge>
                  <Badge variant="secondary">Sedang: {dist.sedang}</Badge>
                  <Badge variant="secondary">Sulit: {dist.sulit}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <p className="mb-4 rounded-xl border border-warning/40 bg-warning/10 px-3.5 py-2.5 text-xs leading-relaxed text-foreground">
            Ini adalah <span className="font-semibold">konfigurasi simulasi latihan</span> yang
            ditentukan aplikasi — jumlah soal dan durasi <span className="font-semibold">bukan</span>{" "}
            format resmi Seleksi Mandiri UNY.
          </p>

          <Button
            size="lg"
            className="h-14 w-full text-base font-bold"
            onClick={start}
            disabled={!ready || selection.length === 0}
          >
            <Play className="mr-2 h-5 w-5" />
            Mulai Simulasi
          </Button>
        </>
      )}
    </div>
  );
}

function Row({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Clock;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-3">
      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-secondary text-secondary-foreground">
        <Icon className="h-4.5 w-4.5" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-semibold">{value}</p>
      </div>
    </div>
  );
}
