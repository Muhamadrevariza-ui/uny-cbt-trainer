import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Check, RotateCcw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getResult } from "@/lib/storage";
import { SECTION_SHORT } from "@/lib/analysis";
import type { ExamResult, QuestionResult } from "@/lib/types";

export const Route = createFileRoute("/review/$id")({
  head: () => ({
    meta: [
      { title: "Pembahasan Soal — UNY CBT Trainer" },
      { name: "description", content: "Review dan pembahasan soal simulasi CBT latihan." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ReviewPage,
});

const LETTERS = ["A", "B", "C", "D", "E"];

type Filter = "all" | "wrong" | "correct" | "empty" | "doubt";

const FILTERS: { key: Filter; label: string }[] = [
  { key: "all", label: "Semua" },
  { key: "wrong", label: "Salah" },
  { key: "correct", label: "Benar" },
  { key: "empty", label: "Kosong" },
  { key: "doubt", label: "Ragu-ragu" },
];

function matches(r: QuestionResult, f: Filter): boolean {
  switch (f) {
    case "all":
      return true;
    case "wrong":
      return r.userAnswer !== null && !r.isCorrect;
    case "correct":
      return r.isCorrect;
    case "empty":
      return r.userAnswer === null;
    case "doubt":
      return r.doubtful;
  }
}

function ReviewPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const [result, setResult] = useState<ExamResult | null>(null);
  const [filter, setFilter] = useState<Filter>("all");

  useEffect(() => {
    const r = getResult(id);
    if (!r) {
      navigate({ to: "/" });
      return;
    }
    setResult(r);
  }, [id, navigate]);

  if (!result) {
    return (
      <div className="grid min-h-screen place-items-center text-sm text-muted-foreground">
        Memuat pembahasan…
      </div>
    );
  }

  const filtered = result.questions.filter((r) => matches(r, filter));

  return (
    <div className="mx-auto min-h-screen w-full max-w-2xl px-4 py-4 pb-10">
      <div className="mb-4 flex items-center gap-3">
        <Link
          to="/results/$id"
          params={{ id: result.id }}
          className="grid h-9 w-9 place-items-center rounded-lg border bg-card"
          aria-label="Kembali ke hasil"
        >
          <ArrowLeft className="h-4.5 w-4.5" />
        </Link>
        <div className="min-w-0">
          <h1 className="truncate text-lg font-extrabold">Pembahasan Soal</h1>
          <p className="truncate text-xs text-muted-foreground">{result.title}</p>
        </div>
      </div>

      <div className="sticky top-0 z-20 -mx-4 mb-4 flex gap-2 overflow-x-auto bg-background/95 px-4 py-2 backdrop-blur">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-semibold transition-colors ${
              filter === f.key
                ? "border-primary bg-primary text-primary-foreground"
                : "bg-card text-foreground"
            }`}
          >
            {f.label} ({result.questions.filter((r) => matches(r, f.key)).length})
          </button>
        ))}
      </div>

      {result.incorrect + result.unanswered > 0 && (
        <Button asChild variant="outline" className="mb-4 h-11 w-full font-bold">
          <Link to="/setup/$mode" params={{ mode: "review" }}>
            <RotateCcw className="mr-2 h-4.5 w-4.5" />
            Latih Ulang Soal Salah
          </Link>
        </Button>
      )}

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center text-sm text-muted-foreground">
            Tidak ada soal pada filter ini.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3">
          {filtered.map((r) => {
            const qNumber = result.questions.indexOf(r) + 1;
            return (
              <Card key={r.question.id}>
                <CardContent className="p-4">
                  <div className="mb-2.5 flex flex-wrap items-center gap-1.5">
                    <span
                      className={`grid h-6 w-6 place-items-center rounded-full ${
                        r.isCorrect
                          ? "bg-success text-success-foreground"
                          : "bg-destructive text-destructive-foreground"
                      }`}
                    >
                      {r.isCorrect ? <Check className="h-3.5 w-3.5" /> : <X className="h-3.5 w-3.5" />}
                    </span>
                    <span className="text-sm font-bold">Soal {qNumber}</span>
                    <Badge variant="secondary">{SECTION_SHORT[r.question.section]}</Badge>
                    <Badge variant="outline">{r.question.subskill}</Badge>
                    <Badge variant="outline" className="capitalize">
                      {r.question.difficulty}
                    </Badge>
                    {r.doubtful && (
                      <Badge className="bg-warning/15 text-warning-foreground hover:bg-warning/15">
                        Ragu
                      </Badge>
                    )}
                  </div>

                  {r.question.passage && (
                    <div className="mb-2.5 rounded-lg bg-muted/60 p-3 text-sm leading-relaxed">
                      {r.question.passage}
                    </div>
                  )}
                  <p className="mb-3 text-sm font-medium leading-relaxed">{r.question.question}</p>

                  <div className="mb-3 grid gap-1.5">
                    {r.question.options.map((opt, oi) => {
                      const isCorrectOpt = oi === r.question.correctAnswer;
                      const isUserOpt = oi === r.userAnswer;
                      return (
                        <div
                          key={oi}
                          className={`flex items-start gap-2 rounded-lg border px-3 py-2 text-sm ${
                            isCorrectOpt
                              ? "border-success/50 bg-success/10"
                              : isUserOpt
                                ? "border-destructive/50 bg-destructive/10"
                                : "border-transparent"
                          }`}
                        >
                          <span className="font-bold">{LETTERS[oi]}.</span>
                          <span className="leading-relaxed">{opt}</span>
                          {isCorrectOpt && (
                            <span className="ml-auto shrink-0 text-xs font-semibold text-success">
                              Kunci
                            </span>
                          )}
                          {isUserOpt && !isCorrectOpt && (
                            <span className="ml-auto shrink-0 text-xs font-semibold text-destructive">
                              Jawabanmu
                            </span>
                          )}
                        </div>
                      );
                    })}
                    {r.userAnswer === null && (
                      <p className="px-1 text-xs font-medium text-muted-foreground">
                        Tidak dijawab
                      </p>
                    )}
                  </div>

                  <div className="rounded-lg bg-secondary/60 p-3">
                    <p className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                      Pembahasan
                    </p>
                    <p className="text-sm leading-relaxed">{r.question.explanation}</p>
                  </div>

                  <p className="mt-2 text-xs text-muted-foreground">
                    Waktu pengerjaan: {r.timeSpent} dtk (estimasi {r.question.estimatedTime} dtk)
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
