import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Flag, LayoutGrid } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { scoreExam } from "@/lib/engine";
import { clearActiveExam, getActiveExam, saveActiveExam, saveResult } from "@/lib/storage";
import { SECTION_SHORT } from "@/lib/analysis";
import { fmtClock } from "@/lib/format";
import type { ActiveExam } from "@/lib/types";

export const Route = createFileRoute("/exam")({
  head: () => ({
    meta: [
      { title: "Simulasi CBT — UNY CBT Trainer" },
      { name: "description", content: "Sedang mengerjakan simulasi CBT latihan." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ExamPage,
});

const LETTERS = ["A", "B", "C", "D", "E"];

function ExamPage() {
  const navigate = useNavigate();
  const [exam, setExam] = useState<ActiveExam | null>(null);
  const [remaining, setRemaining] = useState<number | null>(null);
  const [navOpen, setNavOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const enteredAt = useRef(Date.now());
  const examRef = useRef<ActiveExam | null>(null);
  const submittingRef = useRef(false);
  examRef.current = exam;

  useEffect(() => {
    const e = getActiveExam();
    if (!e) {
      navigate({ to: "/" });
      return;
    }
    setExam(e);
    setRemaining(Math.max(0, Math.round((e.endsAt - Date.now()) / 1000)));
    enteredAt.current = Date.now();
  }, [navigate]);

  const update = useCallback((fn: (prev: ActiveExam) => ActiveExam) => {
    setExam((prev) => {
      if (!prev) return prev;
      const next = fn(prev);
      saveActiveExam(next);
      return next;
    });
  }, []);

  /** Add elapsed time on current question, return updated exam object. */
  const flushTime = useCallback((e: ActiveExam): ActiveExam => {
    const now = Date.now();
    const spent = Math.round((now - enteredAt.current) / 1000);
    enteredAt.current = now;
    const timeSpent = [...e.timeSpent];
    timeSpent[e.currentIndex] += spent;
    return { ...e, timeSpent };
  }, []);

  const submit = useCallback(() => {
    if (submittingRef.current) return;
    const e = examRef.current;
    if (!e) return;
    submittingRef.current = true;
    const finalExam = flushTime(e);
    const result = scoreExam(finalExam);
    saveResult(result);
    clearActiveExam();
    navigate({ to: "/results/$id", params: { id: result.id } });
  }, [flushTime, navigate]);

  // countdown — keeps running while navigating between questions; auto-submit at 0
  useEffect(() => {
    if (!exam) return;
    const endsAt = exam.endsAt;
    const t = setInterval(() => {
      const r = Math.max(0, Math.round((endsAt - Date.now()) / 1000));
      setRemaining(r);
      if (r <= 0) submit();
    }, 500);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [exam?.endsAt, submit]);

  if (!exam || remaining === null) {
    return (
      <div className="grid min-h-screen place-items-center text-sm text-muted-foreground">
        Memuat simulasi…
      </div>
    );
  }

  const i = exam.currentIndex;
  const q = exam.questions[i];
  const answeredCount = exam.answers.filter((a) => a !== null).length;
  const doubtfulCount = exam.doubtful.filter(Boolean).length;
  const unansweredCount = exam.questions.length - answeredCount;

  const goTo = (idx: number) => {
    if (idx < 0 || idx >= exam.questions.length) return;
    update((prev) => ({ ...flushTime(prev), currentIndex: idx }));
    setNavOpen(false);
  };

  const selectAnswer = (opt: number) => {
    update((prev) => {
      const answers = [...prev.answers];
      answers[prev.currentIndex] = answers[prev.currentIndex] === opt ? null : opt;
      return { ...prev, answers };
    });
  };

  const toggleDoubt = () => {
    update((prev) => {
      const doubtful = [...prev.doubtful];
      doubtful[prev.currentIndex] = !doubtful[prev.currentIndex];
      return { ...prev, doubtful };
    });
  };

  const lowTime = remaining <= 60;

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-2xl flex-col">
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b bg-background/95 backdrop-blur">
        <div className="flex items-center gap-2 px-4 py-2.5">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold leading-tight">{exam.title}</p>
            <p className="truncate text-[11px] text-muted-foreground">
              {SECTION_SHORT[q.section]}
            </p>
          </div>
          <div
            className={`tabular-time shrink-0 rounded-lg px-3 py-1.5 text-sm font-bold ${
              lowTime
                ? "bg-destructive text-destructive-foreground"
                : "bg-secondary text-secondary-foreground"
            }`}
          >
            {fmtClock(remaining)}
          </div>
          <Button
            variant="outline"
            size="sm"
            className="shrink-0"
            onClick={() => setConfirmOpen(true)}
          >
            Selesai
          </Button>
        </div>
        <div className="h-1 w-full bg-secondary">
          <div
            className="h-full bg-primary transition-all"
            style={{ width: `${(answeredCount / exam.questions.length) * 100}%` }}
          />
        </div>
      </header>

      {/* Question */}
      <main className="flex-1 px-4 pb-40 pt-4">
        <div className="mb-3 flex items-center justify-between">
          <p className="text-sm font-bold">
            Soal {i + 1} <span className="font-normal text-muted-foreground">dari {exam.questions.length}</span>
          </p>
          {exam.doubtful[i] && (
            <span className="rounded-full bg-warning/15 px-2.5 py-1 text-xs font-semibold text-warning-foreground">
              Ragu-ragu
            </span>
          )}
        </div>

        {q.passage && (
          <div className="mb-4 rounded-xl border bg-muted/60 p-4 text-[15px] leading-relaxed">
            {q.passage}
          </div>
        )}

        <p className="mb-4 text-[16px] font-medium leading-relaxed">{q.question}</p>

        <div className="grid gap-2.5">
          {q.options.map((opt, oi) => {
            const selected = exam.answers[i] === oi;
            return (
              <button
                key={oi}
                onClick={() => selectAnswer(oi)}
                className={`flex items-start gap-3 rounded-xl border-2 p-3.5 text-left transition-colors ${
                  selected
                    ? "border-primary bg-primary/10"
                    : "border-border bg-card active:bg-accent"
                }`}
              >
                <span
                  className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-sm font-bold ${
                    selected
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground"
                  }`}
                >
                  {LETTERS[oi]}
                </span>
                <span className="pt-0.5 text-[15px] leading-relaxed">{opt}</span>
              </button>
            );
          })}
        </div>
      </main>

      {/* Bottom controls */}
      <div className="fixed inset-x-0 bottom-0 z-30 border-t bg-background/95 backdrop-blur">
        <div className="mx-auto grid max-w-2xl grid-cols-[auto_1fr_auto_auto] items-center gap-2 px-4 py-3">
          <Button
            variant={exam.doubtful[i] ? "default" : "outline"}
            size="icon"
            className={`h-11 w-11 ${exam.doubtful[i] ? "bg-warning text-warning-foreground hover:bg-warning" : ""}`}
            onClick={toggleDoubt}
            aria-label="Tandai ragu-ragu"
          >
            <Flag className="h-5 w-5" />
          </Button>
          <Button
            variant="outline"
            className="h-11"
            onClick={() => setNavOpen(true)}
          >
            <LayoutGrid className="mr-2 h-4.5 w-4.5" />
            {answeredCount}/{exam.questions.length}
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-11 w-11"
            onClick={() => goTo(i - 1)}
            disabled={i === 0}
            aria-label="Soal sebelumnya"
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          {i === exam.questions.length - 1 ? (
            <Button className="h-11 px-4 font-bold" onClick={() => setConfirmOpen(true)}>
              Selesai
            </Button>
          ) : (
            <Button
              size="icon"
              className="h-11 w-11"
              onClick={() => goTo(i + 1)}
              aria-label="Soal berikutnya"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          )}
        </div>
      </div>

      {/* Question navigator — bottom sheet */}
      <Drawer open={navOpen} onOpenChange={setNavOpen}>
        <DrawerContent>
          <DrawerHeader>
            <DrawerTitle>Navigasi Soal</DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-8">
            <div className="mb-4 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
              <Legend className="bg-primary" label="Dijawab" />
              <Legend className="bg-warning" label="Ragu-ragu" />
              <Legend className="border bg-card" label="Belum dijawab" />
              <Legend className="border-2 border-primary bg-card" label="Soal saat ini" />
            </div>
            <div className="grid grid-cols-6 gap-2">
              {exam.questions.map((_, qi) => {
                const answered = exam.answers[qi] !== null;
                const doubt = exam.doubtful[qi];
                const current = qi === i;
                let cls = "border bg-card text-foreground";
                if (answered) cls = "bg-primary text-primary-foreground";
                if (doubt) cls = "bg-warning text-warning-foreground";
                if (current) cls += " ring-2 ring-primary ring-offset-2 ring-offset-background";
                return (
                  <button
                    key={qi}
                    onClick={() => goTo(qi)}
                    className={`grid h-11 place-items-center rounded-lg text-sm font-bold ${cls}`}
                  >
                    {qi + 1}
                  </button>
                );
              })}
            </div>
          </div>
        </DrawerContent>
      </Drawer>

      {/* Submit confirmation */}
      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>Kumpulkan jawaban?</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-2 pt-1">
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg bg-secondary p-2.5">
                    <p className="text-lg font-extrabold text-foreground">{answeredCount}</p>
                    <p className="text-[11px]">Dijawab</p>
                  </div>
                  <div className="rounded-lg bg-secondary p-2.5">
                    <p className="text-lg font-extrabold text-foreground">{unansweredCount}</p>
                    <p className="text-[11px]">Kosong</p>
                  </div>
                  <div className="rounded-lg bg-secondary p-2.5">
                    <p className="text-lg font-extrabold text-foreground">{doubtfulCount}</p>
                    <p className="text-[11px]">Ragu-ragu</p>
                  </div>
                </div>
                {unansweredCount > 0 && (
                  <p className="text-xs">
                    Masih ada {unansweredCount} soal belum dijawab. Yakin ingin mengumpulkan?
                  </p>
                )}
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Lanjut Mengerjakan</AlertDialogCancel>
            <AlertDialogAction onClick={submit}>Kumpulkan</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Legend({ className, label }: { className: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className={`inline-block h-3 w-3 rounded ${className}`} />
      {label}
    </span>
  );
}
