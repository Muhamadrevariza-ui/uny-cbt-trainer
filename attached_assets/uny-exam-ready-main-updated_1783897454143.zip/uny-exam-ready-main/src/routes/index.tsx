import { Link, createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  BookOpen,
  ChevronRight,
  ClipboardList,
  RotateCcw,
  Target,
  TrendingDown,
  TrendingUp,
  Zap,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getHistory } from "@/lib/storage";
import { aggregate, computeReadiness, SECTION_SHORT } from "@/lib/analysis";
import { fmtDate } from "@/lib/format";
import type { ExamResult } from "@/lib/types";

export const Route = createFileRoute("/")({
  component: Dashboard,
});

const MODES = [
  {
    mode: "mini",
    title: "Mini TO",
    desc: "Simulasi singkat 12 soal dari 4 bagian",
    icon: Zap,
  },
  {
    mode: "full",
    title: "Full TO",
    desc: "Simulasi lengkap 40 soal, semua bagian",
    icon: ClipboardList,
  },
  {
    mode: "materi",
    title: "Latihan Per Materi",
    desc: "Pilih bagian atau subskill tertentu",
    icon: BookOpen,
  },
  {
    mode: "review",
    title: "Review Kesalahan",
    desc: "Latih ulang soal yang pernah salah",
    icon: RotateCcw,
  },
] as const;

function Dashboard() {
  const [history, setHistory] = useState<ExamResult[] | null>(null);
  useEffect(() => setHistory(getHistory()), []);

  const stats = history ? aggregate(history) : null;
  const readiness = history && history.length > 0 ? computeReadiness(history) : null;
  const recent = history ? [...history].reverse().slice(0, 5) : [];

  return (
    <AppShell>
      <section className="mb-5">
        <h1 className="text-xl font-extrabold tracking-tight">Halo, Pejuang UNY!</h1>
        <p className="mt-0.5 text-sm text-muted-foreground">
          Konsisten latihan hari ini, satu langkah lebih dekat ke kampus impian.
        </p>
      </section>

      <section className="mb-5 grid grid-cols-2 gap-3">
        <StatBox label="Skor terakhir" value={stats?.latestScore != null ? String(stats.latestScore) : "—"} />
        <StatBox label="Simulasi selesai" value={stats ? String(stats.totalExams) : "—"} />
        <StatBox label="Akurasi rata-rata" value={stats && stats.totalQuestions ? `${stats.avgAccuracy}%` : "—"} />
        <StatBox label="Soal dijawab" value={stats ? String(stats.totalQuestions) : "—"} />
      </section>

      {stats && (stats.strongestSection || stats.weakestSection) && (
        <section className="mb-5 grid grid-cols-1 gap-2">
          {stats.strongestSection && (
            <div className="flex items-center gap-2.5 rounded-xl border bg-card px-3.5 py-2.5">
              <TrendingUp className="h-4 w-4 shrink-0 text-success" />
              <p className="min-w-0 truncate text-sm">
                Terkuat: <span className="font-semibold">{SECTION_SHORT[stats.strongestSection]}</span>{" "}
                <span className="text-muted-foreground">
                  ({stats.sectionAccuracy[stats.strongestSection]?.accuracy}%)
                </span>
              </p>
            </div>
          )}
          {stats.weakestSection && stats.weakestSection !== stats.strongestSection && (
            <div className="flex items-center gap-2.5 rounded-xl border bg-card px-3.5 py-2.5">
              <TrendingDown className="h-4 w-4 shrink-0 text-destructive" />
              <p className="min-w-0 truncate text-sm">
                Terlemah: <span className="font-semibold">{SECTION_SHORT[stats.weakestSection]}</span>{" "}
                <span className="text-muted-foreground">
                  ({stats.sectionAccuracy[stats.weakestSection]?.accuracy}%)
                </span>
              </p>
            </div>
          )}
        </section>
      )}

      <section className="mb-5">
        <h2 className="mb-2.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Mulai Latihan
        </h2>
        <div className="grid grid-cols-1 gap-3">
          {MODES.map(({ mode, title, desc, icon: Icon }) => (
            <Link key={mode} to="/setup/$mode" params={{ mode }}>
              <Card className="transition-colors active:bg-accent">
                <CardContent className="flex items-center gap-3.5 p-4">
                  <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                    <Icon className="h-5.5 w-5.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-bold">{title}</p>
                    <p className="truncate text-sm text-muted-foreground">{desc}</p>
                  </div>
                  <ChevronRight className="h-5 w-5 shrink-0 text-muted-foreground" />
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {readiness && (
        <section className="mb-5">
          <Link to="/progress">
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="flex items-center gap-3.5 p-4">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground">
                  <Target className="h-5.5 w-5.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Estimasi Kesiapan UNY
                  </p>
                  <p className="font-bold">{readiness.status}</p>
                  <p className="text-xs text-muted-foreground">
                    Indikator latihan — bukan prediksi resmi UNY
                  </p>
                </div>
                <ChevronRight className="h-5 w-5 shrink-0 text-muted-foreground" />
              </CardContent>
            </Card>
          </Link>
        </section>
      )}

      <section>
        <h2 className="mb-2.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Riwayat Terbaru
        </h2>
        {recent.length === 0 ? (
          <Card>
            <CardContent className="p-5 text-center text-sm text-muted-foreground">
              Belum ada simulasi. Mulai dari <span className="font-semibold">Mini TO</span> untuk
              mencoba!
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-2">
            {recent.map((r) => (
              <Link key={r.id} to="/results/$id" params={{ id: r.id }}>
                <Card className="transition-colors active:bg-accent">
                  <CardContent className="flex items-center gap-3 p-3.5">
                    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-secondary text-sm font-extrabold text-secondary-foreground">
                      {r.score}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{r.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {fmtDate(r.date)} · {r.correct}/{r.totalQuestions} benar
                      </p>
                    </div>
                    <Badge variant="secondary" className="shrink-0">
                      {r.accuracy}%
                    </Badge>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </section>
    </AppShell>
  );
}

function StatBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border bg-card px-3.5 py-3">
      <p className="text-2xl font-extrabold tabular-time">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
