import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Target } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getHistory } from "@/lib/storage";
import {
  aggregate,
  computeReadiness,
  SECTION_SHORT,
  type Readiness,
} from "@/lib/analysis";
import { fmtDate } from "@/lib/format";
import type { ExamResult, SectionId } from "@/lib/types";

export const Route = createFileRoute("/progress")({
  head: () => ({
    meta: [
      { title: "Progres & Kesiapan — UNY CBT Trainer" },
      {
        name: "description",
        content: "Tren skor, performa per bagian, dan estimasi kesiapan latihan Seleksi Mandiri UNY.",
      },
    ],
  }),
  component: ProgressPage,
});

const STATUS_TONE: Record<Readiness["status"], string> = {
  "Perlu Penguatan": "bg-destructive/10 text-destructive",
  Berkembang: "bg-warning/15 text-warning-foreground",
  Kompetitif: "bg-primary/10 text-primary",
  "Sangat Kuat": "bg-success/15 text-success",
};

function ProgressPage() {
  const [history, setHistory] = useState<ExamResult[] | null>(null);
  useEffect(() => setHistory(getHistory()), []);

  if (history === null) {
    return (
      <AppShell title="Progres">
        <p className="py-10 text-center text-sm text-muted-foreground">Memuat…</p>
      </AppShell>
    );
  }

  if (history.length === 0) {
    return (
      <AppShell title="Progres">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="font-bold">Belum ada data progres</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Selesaikan simulasi pertamamu untuk melihat tren skor dan estimasi kesiapan.
            </p>
            <Link
              to="/setup/$mode"
              params={{ mode: "mini" }}
              className="mt-4 inline-flex h-11 items-center justify-center rounded-lg bg-primary px-5 text-sm font-bold text-primary-foreground"
            >
              Mulai Mini TO
            </Link>
          </CardContent>
        </Card>
      </AppShell>
    );
  }

  const stats = aggregate(history);
  const readiness = computeReadiness(history);

  const trendData = history.map((r, idx) => ({
    name: `#${idx + 1}`,
    skor: r.score,
    akurasi: r.accuracy,
  }));

  const sectionData = (Object.entries(stats.sectionAccuracy) as [SectionId, { accuracy: number }][]).map(
    ([s, v]) => ({ name: SECTION_SHORT[s], akurasi: v.accuracy }),
  );

  return (
    <AppShell title="Progres & Kesiapan">
      {/* Readiness */}
      <section className="mb-5">
        <h2 className="mb-2.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Estimasi Kesiapan UNY
        </h2>
        <Card className="border-primary/30">
          <CardContent className="p-4">
            <div className="mb-3 flex items-center gap-3">
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground">
                <Target className="h-5.5 w-5.5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground">
                  Target: Statistika UNY · Matematika UNY
                </p>
                <span
                  className={`mt-0.5 inline-block rounded-full px-3 py-1 text-sm font-bold ${STATUS_TONE[readiness.status]}`}
                >
                  {readiness.status}
                </span>
              </div>
            </div>

            {!readiness.enoughData && (
              <p className="mb-3 text-xs text-muted-foreground">
                Data masih terbatas — kerjakan lebih banyak simulasi agar estimasi lebih stabil.
              </p>
            )}

            {readiness.strengths.length > 0 && (
              <div className="mb-3">
                <p className="mb-1 text-xs font-bold text-success">Kekuatan</p>
                <ul className="grid gap-1 text-sm">
                  {readiness.strengths.map((s, i) => (
                    <li key={i} className="leading-snug">• {s}</li>
                  ))}
                </ul>
              </div>
            )}
            {readiness.weaknesses.length > 0 && (
              <div className="mb-3">
                <p className="mb-1 text-xs font-bold text-destructive">Perlu Diperbaiki</p>
                <ul className="grid gap-1 text-sm">
                  {readiness.weaknesses.map((s, i) => (
                    <li key={i} className="leading-snug">• {s}</li>
                  ))}
                </ul>
              </div>
            )}
            <div className="mb-3">
              <p className="mb-1 text-xs font-bold text-primary">Prioritas Peningkatan</p>
              <ul className="grid gap-1 text-sm">
                {readiness.priorities.map((s, i) => (
                  <li key={i} className="leading-snug">
                    {i + 1}. {s}
                  </li>
                ))}
              </ul>
            </div>

            <p className="rounded-lg bg-muted/70 p-3 text-[11px] leading-relaxed text-muted-foreground">
              Estimasi ini adalah <span className="font-semibold">indikator kesiapan latihan</span>{" "}
              berdasarkan performa di aplikasi ini saja — bukan prediksi resmi kelulusan atau
              passing grade Seleksi Mandiri UNY. UNY tidak menerbitkan ambang skor resmi yang
              digunakan aplikasi ini.
            </p>
          </CardContent>
        </Card>
      </section>

      {/* Score trend */}
      <section className="mb-5">
        <h2 className="mb-2.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Tren Skor & Akurasi
        </h2>
        <Card>
          <CardContent className="p-4">
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trendData} margin={{ top: 5, right: 5, bottom: 0, left: -22 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="var(--muted-foreground)" />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: 12,
                      fontSize: 12,
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="skor"
                    stroke="var(--chart-1)"
                    strokeWidth={2.5}
                    dot={{ r: 3 }}
                    name="Skor"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Section accuracy */}
      <section className="mb-5">
        <h2 className="mb-2.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Performa Per Bagian
        </h2>
        <Card>
          <CardContent className="p-4">
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sectionData} margin={{ top: 5, right: 5, bottom: 0, left: -22 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: 12,
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="akurasi" fill="var(--chart-1)" radius={[6, 6, 0, 0]} name="Akurasi %" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Recent simulations */}
      <section>
        <h2 className="mb-2.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Simulasi Terakhir
        </h2>
        <div className="grid gap-2">
          {[...history].reverse().slice(0, 10).map((r) => (
            <Link key={r.id} to="/results/$id" params={{ id: r.id }}>
              <Card className="transition-colors active:bg-accent">
                <CardContent className="flex items-center gap-3 p-3.5">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-secondary text-sm font-extrabold">
                    {r.score}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{r.title}</p>
                    <p className="text-xs text-muted-foreground">{fmtDate(r.date)}</p>
                  </div>
                  <Badge variant="secondary" className="shrink-0">
                    {r.correct}/{r.totalQuestions}
                  </Badge>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </AppShell>
  );
}
