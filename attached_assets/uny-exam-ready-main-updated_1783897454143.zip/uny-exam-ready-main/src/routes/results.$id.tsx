import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, BookOpenCheck, RotateCcw, Timer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { getHistory, getResult } from "@/lib/storage";
import {
  aggregate,
  computePriorities,
  SECTION_LABELS,
  type Recommendation,
  type SubskillStat,
} from "@/lib/analysis";
import { fmtClock } from "@/lib/format";
import type { ExamResult, SectionId } from "@/lib/types";

export const Route = createFileRoute("/results/$id")({
  head: () => ({
    meta: [
      { title: "Hasil Simulasi — UNY CBT Trainer" },
      { name: "description", content: "Hasil dan analisis simulasi CBT latihan." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResultsPage,
});

function ResultsPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const [result, setResult] = useState<ExamResult | null>(null);
  const [recs, setRecs] = useState<Recommendation[]>([]);
  const [subskills, setSubskills] = useState<SubskillStat[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const r = getResult(id);
    if (!r) {
      navigate({ to: "/" });
      return;
    }
    setResult(r);
    setSubskills(aggregate([r]).subskills);
    setRecs(computePriorities(aggregate(getHistory())));
    setLoaded(true);
  }, [id, navigate]);

  if (!loaded || !result) {
    return (
      <div className="grid min-h-screen place-items-center text-sm text-muted-foreground">
        Memuat hasil…
      </div>
    );
  }

  const avgTimePerQ = result.totalQuestions
    ? Math.round(result.timeUsedSec / result.totalQuestions)
    : 0;

  const strongest = [...subskills].filter((s) => s.attempts >= 1).sort((a, b) => b.accuracy - a.accuracy);
  const weakest = [...strongest].reverse();
  const slowest = [...subskills]
    .filter((s) => s.avgEstimated > 0)
    .sort((a, b) => b.avgTime / b.avgEstimated - a.avgTime / a.avgEstimated);

  return (
    <div className="mx-auto min-h-screen w-full max-w-2xl px-4 py-4 pb-10">
      <div className="mb-4 flex items-center gap-3">
        <Link
          to="/"
          className="grid h-9 w-9 place-items-center rounded-lg border bg-card"
          aria-label="Kembali ke beranda"
        >
          <ArrowLeft className="h-4.5 w-4.5" />
        </Link>
        <div className="min-w-0">
          <h1 className="truncate text-lg font-extrabold">Hasil Simulasi</h1>
          <p className="truncate text-xs text-muted-foreground">{result.title}</p>
        </div>
      </div>

      {/* Score hero */}
      <Card className="mb-4 border-primary/30 bg-primary/5">
        <CardContent className="p-5 text-center">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Skor Keseluruhan
          </p>
          <p className="my-1 text-6xl font-extrabold tabular-time text-primary">{result.score}</p>
          <p className="text-sm text-muted-foreground">Akurasi {result.accuracy}%</p>
        </CardContent>
      </Card>

      <div className="mb-4 grid grid-cols-3 gap-2">
        <MiniStat label="Benar" value={String(result.correct)} tone="text-success" />
        <MiniStat label="Salah" value={String(result.incorrect)} tone="text-destructive" />
        <MiniStat label="Kosong" value={String(result.unanswered)} tone="text-muted-foreground" />
      </div>

      <Card className="mb-4">
        <CardContent className="flex items-center justify-between p-4 text-sm">
          <span className="flex items-center gap-2 text-muted-foreground">
            <Timer className="h-4 w-4" /> Waktu terpakai
          </span>
          <span className="font-bold tabular-time">
            {fmtClock(result.timeUsedSec)}{" "}
            <span className="font-normal text-muted-foreground">(~{avgTimePerQ} dtk/soal)</span>
          </span>
        </CardContent>
      </Card>

      {/* Per-section */}
      <h2 className="mb-2.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">
        Performa Per Bagian
      </h2>
      <div className="mb-5 grid gap-2.5">
        {(Object.entries(result.sections) as [SectionId, NonNullable<ExamResult["sections"][SectionId]>][]).map(
          ([s, v]) => (
            <Card key={s}>
              <CardContent className="p-4">
                <div className="mb-1.5 flex items-center justify-between gap-2">
                  <p className="min-w-0 truncate text-sm font-bold">{SECTION_LABELS[s]}</p>
                  <span
                    className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                      v.accuracy >= 70
                        ? "bg-success/15 text-success"
                        : v.accuracy >= 50
                          ? "bg-warning/15 text-warning-foreground"
                          : "bg-destructive/10 text-destructive"
                    }`}
                  >
                    {v.accuracy >= 70 ? "Baik" : v.accuracy >= 50 ? "Cukup" : "Perlu Latihan"}
                  </span>
                </div>
                <Progress value={v.accuracy} className="mb-2 h-2" />
                <p className="text-xs text-muted-foreground">
                  Akurasi {v.accuracy}% · {v.correct} benar / {v.incorrect} salah / {v.unanswered}{" "}
                  kosong · rata-rata {v.avgTime} dtk/soal
                </p>
              </CardContent>
            </Card>
          ),
        )}
      </div>

      {/* Skill analysis */}
      <h2 className="mb-2.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">
        Analisis Subskill
      </h2>
      <Card className="mb-5">
        <CardContent className="grid gap-3 p-4 text-sm">
          {strongest[0] && (
            <p>
              <span className="font-semibold text-success">Terkuat:</span> {strongest[0].subskill}{" "}
              ({strongest[0].accuracy}%)
            </p>
          )}
          {weakest[0] && (
            <p>
              <span className="font-semibold text-destructive">Terlemah:</span>{" "}
              {weakest[0].subskill} ({weakest[0].accuracy}%)
            </p>
          )}
          {slowest[0] && slowest[0].avgTime > slowest[0].avgEstimated && (
            <p>
              <span className="font-semibold text-warning-foreground">Paling lambat:</span>{" "}
              {slowest[0].subskill} ({slowest[0].avgTime} dtk vs estimasi {slowest[0].avgEstimated}{" "}
              dtk)
            </p>
          )}
        </CardContent>
      </Card>

      {/* Priorities */}
      <h2 className="mb-2.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">
        Prioritas Belajar Berikutnya
      </h2>
      <div className="mb-6 grid gap-2.5">
        {recs.map((r, ri) => (
          <Card key={ri}>
            <CardContent className="flex gap-3 p-4">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                {ri + 1}
              </span>
              <div className="min-w-0">
                <p className="text-sm font-bold">{r.title}</p>
                <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{r.detail}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-2.5">
        <Button asChild size="lg" className="h-12 font-bold">
          <Link to="/review/$id" params={{ id: result.id }}>
            <BookOpenCheck className="mr-2 h-5 w-5" />
            Lihat Pembahasan Soal
          </Link>
        </Button>
        {result.incorrect + result.unanswered > 0 && (
          <Button asChild variant="outline" size="lg" className="h-12 font-bold">
            <Link to="/setup/$mode" params={{ mode: "review" }}>
              <RotateCcw className="mr-2 h-5 w-5" />
              Latih Ulang Soal Salah
            </Link>
          </Button>
        )}
        <Button asChild variant="ghost">
          <Link to="/">Kembali ke Beranda</Link>
        </Button>
      </div>
    </div>
  );
}

function MiniStat({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="rounded-xl border bg-card p-3 text-center">
      <p className={`text-2xl font-extrabold tabular-time ${tone}`}>{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
