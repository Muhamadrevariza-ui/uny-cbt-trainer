import { Link } from "@tanstack/react-router";
import { BarChart3, GraduationCap, Home } from "lucide-react";
import type { ReactNode } from "react";

/** Mobile-first shell: sticky header + bottom navigation. */
export function AppShell({ children, title }: { children: ReactNode; title?: string }) {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-2xl flex-col">
      <header className="sticky top-0 z-30 border-b bg-background/90 backdrop-blur">
        <div className="flex items-center gap-2.5 px-4 py-3">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground">
            <GraduationCap className="h-4.5 w-4.5" />
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold leading-tight">
              {title ?? "UNY CBT Trainer"}
            </p>
            <p className="text-[11px] leading-tight text-muted-foreground">
              Persiapan Seleksi Mandiri UNY 2026
            </p>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 pb-24 pt-4">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t bg-background/95 backdrop-blur">
        <div className="mx-auto grid max-w-2xl grid-cols-2">
          <Link
            to="/"
            className="flex flex-col items-center gap-0.5 py-2.5 text-xs font-medium text-muted-foreground"
            activeProps={{ className: "text-primary" }}
            activeOptions={{ exact: true }}
          >
            <Home className="h-5 w-5" />
            Beranda
          </Link>
          <Link
            to="/progress"
            className="flex flex-col items-center gap-0.5 py-2.5 text-xs font-medium text-muted-foreground"
            activeProps={{ className: "text-primary" }}
          >
            <BarChart3 className="h-5 w-5" />
            Progres
          </Link>
        </div>
      </nav>
    </div>
  );
}
